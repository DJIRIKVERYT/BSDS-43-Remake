![Discord link:](https://discord.gg/mt4dUxXryh)

![ANDROID 1 (MEDIAFIRE) (UPDATED!) :] (https://www.mediafire.com/file/njptm3nhto0xm19/com.projectsbsds.v43229-rev1.apk/file)

![ANDROID 2 (GOOGLE DRIVE) (UPDATED!) :] (https://drive.google.com/file/d/1BKjqkRdPO9FAA5HcEPdiEKzUBhtifwl7/view?usp=sharing)

## Requirements: ##
1. Brain...
2. Edit IP to client!

## How to play BSDS: ##
1. download server and apk
2. install the apk
3. download pydroid (if you want to run from the phone)
4. open in pydroid Core.py located in the server folder
5. click on the run button
6. now open the game and play

## Change the ip address and port (if needed) in libprojectbsds.config.so located in the lib folder of the apk ##

![Screenshot_20220430-195745](https://user-images.githubusercontent.com/52799759/166126704-d3733802-daf2-4594-9070-24ed776b6f1c.png)
