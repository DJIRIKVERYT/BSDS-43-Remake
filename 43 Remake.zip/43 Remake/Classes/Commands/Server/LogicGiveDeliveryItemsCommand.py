from Classes.Commands.LogicServerCommand import LogicServerCommand
from Database.DatabaseHandler import DatabaseHandler
import random
import json


class LogicGiveDeliveryItemsCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        self.gold = 30
        brawler = random.randint(0, 58)
        
        self.writeVInt(0)

        self.writeVInt(1)#Count Box

        self.writeVInt(12)#BOX ID

        self.writeVInt(2)#Count item

        self.writeVInt(self.gold)#Value
        self.writeVInt(0)
        self.writeVInt(7)#REWARD ID
        self.writeHexa('00 00 00', 3)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)#Value
        self.writeVInt(16)#Sc id: 16 - brawler 29 - skin 52 - emoji
        self.writeVInt(brawler)#ID
        self.writeVInt(1)#Reward Id
        self.writeHexa('00 00 00', 3)

        self.writeDataReference(53)#ID
        self.writeVInt(10)#Reward Id
        self.writeHexa('00 00 00', 3)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        LogicServerCommand.encode(self, fields)
        return self.messagePayload
        
    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        player_data["Coins"] = player_data["Coins"] + 30
        db_instance.updatePlayerData(player_data, calling_instance)
        #gems
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        player_data["Gems"] = player_data["Gems"] + 30
        db_instance.updatePlayerData(player_data, calling_instance)

    def decode(self, calling_instance):
        fields = {}
        return LogicServerCommand.decode(calling_instance, fields)

    def getCommandType(self):
        return 201